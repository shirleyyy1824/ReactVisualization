# DSCI554 FINAL PROJECT


In the project directory, run:

### `npm install react-scripts`
### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

- Youtube Link : https://youtu.be/TXuAVfkr6Sk
- Paper Link : https://www.overleaf.com/read/rshpgcjcbrwh#b839fc
- Presentation Link : https://docs.google.com/presentation/d/1fgEW90kNBZgiBSz5rpwFzec_KIQuq5lPG4g4uUX_BNk/edit#slide=id.p
