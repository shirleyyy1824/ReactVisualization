import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import * as topojson from 'topojson';

const Mammography = () => {
  const svgRef = useRef();

  useEffect(() => {
    const fetchData = async () => {

      const topoData = await d3.json('/data/counties-10m.json');
      const geoData = topojson.feature(topoData, topoData.objects.counties);

  
      const projection = d3.geoAlbersUsa().fitSize([500, 400], geoData);

    
      const response = await fetch('/data/Mammography.json');
      const data = await response.json();

      const svgContainer = svgRef.current || d3.select('#map-container')
        .append('svg')
        .attr('width', 500)
        .attr('height', 400);

      svgRef.current = svgContainer;

      svgContainer.html('');

      const svg = svgContainer.append('svg')
        .attr('width', 500)
        .attr('height', 400);
       

      svg
        .selectAll('path')
        .data(geoData.features || [])
        .enter()
        .append('path')
        .attr('d', d3.geoPath().projection(projection))
        .attr('fill', '#ccc')
        .attr('stroke', '#fff')
       
      console.log(projection([data[0].longitude, data[0].latitude]));
      const tooltip = d3.select('#map-container').append('div')
      .attr('class', 'tooltip')
      .style('opacity', 0);
     
      const circles = svg.selectAll('circle')
      .data(data)
      .enter()
      .append('circle')
      .attr('r', 2)
      .style('fill', "#EA638C")
      .style('opacity', 0.8)
      .on('mouseover', (event, d) => {
        
        tooltip.transition()
          .duration(500)
          .style('opacity', 0.9);
    
        const formattedAddress = d.address.replace(/\s+/g, '+');
    
        const googleMapsLink = `https://www.google.com/maps/search/?api=1&query=${formattedAddress}`;
    
        tooltip.html(`<strong>${d.name}</strong><br>${d.address}<br><a href="${googleMapsLink}" target="_blank">Open in Google Maps</a>`)
          .style('left', `${event.pageX}+30px`)
          .style('top', `${event.pageY}px`);
      })
      .on('mouseout', () => {
        
        tooltip.transition()
          .duration(2000)
          .style('opacity', 0);
      });
    
      const zoom = d3.zoom()
        .scaleExtent([1, 8]) 
        .on('zoom', (event) => {
          svg.selectAll('path').attr('transform', event.transform);
          circles.attr('transform', event.transform);
        });

  
      svg.call(zoom);
      svg.append('text')
      .attr('x', 250)
      .attr('y', 20)
      .style('font-size', '20px')
      .style('text-anchor', 'middle')
      .text('Mammography Facility Location Map');
      updateCircles(); 

      function updateCircles() {
        circles
          .attr('cx', d => {
            const coordinates = projection([d.longitude, d.latitude]);
            return coordinates ? coordinates[0] : 0;
          })
          .attr('cy', d => {
            const coordinates = projection([d.longitude, d.latitude]);
            return coordinates ? coordinates[1] : 0;
          });
      }
    };

    fetchData();
  }, []);

  return (
    <div id="map-container" className="rounded-viz-container"></div>
  );
};

export default Mammography;
