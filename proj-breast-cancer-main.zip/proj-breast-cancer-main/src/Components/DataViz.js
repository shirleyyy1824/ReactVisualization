import React from 'react';

import SideBar from './SideBar';
import "../App.css";
import MapToggle from './MapToggle';
import LineChart from './LineChart'; 
import Scatterplot from './Scatterplot'; 
import MedLine from './MedLine'; 
import CaseBar from './CaseBar';
import AgeBar from './AgeBar';
import RaceBar from './RaceBar';
import PieChart from './PieChart';
function App() {
  return (
    <div className="container-fluid">
   <div className="row ">
    
      <div className="col-sm-2">
        <SideBar />
      </div>
      <div className="col-sm-10">
        <p className="textbox">In this dashboard, we unravel a complex issue by blending medical data with its sociological dimensions. 
        We're not just looking at the medical aspects like incidence rates and survival stats; 
        we're also diving into the social factors – things like how often people get screened, access to healthcare, government investments, and public awareness. 
        By bringing together these diverse datasets, the goal is to uncover patterns, highlight disparities, and assess the effectiveness of interventions.</p>
      </div>
      <div className="col-lg-5">
        <MapToggle />
        <CaseBar />
        <AgeBar/>
      </div>
      
      <div className="col-lg-5">
       <Scatterplot/>
       <LineChart/>
       <MedLine/>
       <RaceBar/>
      </div>
      <div className="col-sm-5">
        <PieChart/>
      </div>
      </div> 
      
    </div>
 
  );
}

export default App;
