import React from 'react';
import SideBar from './SideBar';
import "../App.css";
import Scatterplot from './Scatterplot'; 
import MedLine from './MedLine'; 
import TrendMap from './TrendMap';

const Rate = () => {
    return (
      <div className="container-fluid">
     <div className="row ">
       
        <div className="col-sm-2">
          <SideBar />
        </div>
        <div className="col-sm-10">
          <p className="textbox">Breast cancer death rates have been decreasing steadily. The decrease in death rates is the result of finding breast cancer earlier through screening at early stages and increased awareness, as well as better treatments.<br/>
        </p>
        </div>
        <div className="col-lg-5">
          <Scatterplot/>
          <TrendMap/>
          <MedLine/>
        </div>
        <div className="col-lg-5">
        <p className="textbox">This scatterplot focuses on the relationship between breast cancer screening rates and death rates across various demographics or regions. The addition of the R square value provides a statistical measure of how closely the data points in the scatterplot fit a linear regression model, indicating the strength and direction of the correlation between screening rates and mortality. This metric is crucial for interpreting the effectiveness of screening in reducing death rates, offering valuable insights for healthcare policymakers and practitioners. By quantifying the correlation, the scatterplot not only visually represents this vital relationship but also substantiates it with a robust statistical foundation, making it a key component of the breast cancer visualization dashboard that emphasizes the impact of early detection and intervention strategies.</p>
        <br/><br/><br/>
        <p className="textbox">The "Breast Cancer Incidence Rate Choropleth" graphic is a pivotal component of a comprehensive breast cancer visualization dashboard. It intricately maps the age-adjusted breast cancer incidence rates across U.S. states from 1999 to 2020, using a color-coded scheme where deeper shades signify higher rates. A standout feature is the draggable progress bar, allowing users to trace the evolution of these rates year by year. This interactive map not only highlights geographical disparities in incidence rates but also serves as an educational tool, shedding light on long-term trends and the efficacy of public health interventions. This visual element synergizes seamlessly with the broader narrative of the dashboard, which encompasses current cancer statistics, historical trends, and the impact of screening practices, collectively offering a multi-dimensional view of the breast cancer landscape.</p>
        <br/><br/><br/><br/><br/><br/>
        <p className="textbox">The line chart delves into the historical perspective, tracing the incidence and mortality trends of breast cancer over nearly half a century. This longitudinal view allows for a deeper understanding of how breast cancer trends have evolved, highlighting periods of significant increase or decrease in both incidence and mortality rates.</p>
        </div>
        </div>
        </div>
    );
  };
  
  export default Rate;
  