import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import "../App.css";
const TrendMap = () => {
  const svgRef = useRef(null);
  const [selectedYear, setSelectedYear] = useState(1999);

  useEffect(() => {
    const width = 580;
    const height = 400;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);

    const colorScheme = d3.scaleLinear()
      .domain([90, 180])
      .range(["#FED5E0", "#EA638C"]);

    const tooltip = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("opacity", 0);

    let usData;
    let cancerData;

    Promise.all([
      d3.json('/data/gz_2010_us_040_00_500k.json'),
      d3.csv('/data/USCSTrendMap.csv')
    ]).then(function (data) {
      usData = data[0];
      cancerData = data[1];

      usData.features.forEach(feature => {
        const state = feature.properties.NAME;
        const stateData = cancerData.find(d => d.Area === state && d.Year === selectedYear.toString());
        feature.properties.cancerRate = stateData ? parseFloat(stateData['Age-Adjusted Rate']) : null;
      });

      const yOffset = 0;
      


      const projection = d3.geoAlbersUsa()
        .scale(width / 0.9)
        .translate([width / 2, height / 2 + yOffset]);

      const path = d3.geoPath().projection(projection);

      svg.selectAll('path')
        .data(usData.features)
        .join('path')  
        .attr('d', path)
        .attr('fill', d => {
          return d.properties.cancerRate ? colorScheme(d.properties.cancerRate) : '#ccc';
        })
       
.on("mouseover", function (event, d) {
  const stateData = cancerData.find(data => data.Area === d.properties.NAME && data.Year === selectedYear.toString());
  tooltip.transition()
    .duration(200)
    .style("opacity", 0.9);
  tooltip.html(`${d.properties.NAME}<br/>Rate: ${stateData ? stateData['Age-Adjusted Rate'] : 'N/A'}`)
    .style("left", (event.pageX) + "px")
    .style("top", (event.pageY - 28) + "px");
})

        .on("mouseout", function () {
          tooltip.transition()
            .duration(500)
            .style("opacity", 0);
        });
        svg.append('text')
        .attr('x', width / 2)
        .attr('y', 20)
        .attr('text-anchor', 'middle')
        .style('font-size', '20px')
        .text('Breast Cancer Rate Choropleth Map');

  
      const legend = svg.append('g')
        .attr('class', 'legend')
        .attr('transform', 'translate(200, 50)');

      const defs = legend.append("defs");
      const linearGradient = defs.append("linearGradient")
        .attr("id", "color-gradient")
        .attr("x1", "0%")
        .attr("y1", "0%")
        .attr("x2", "100%")
        .attr("y2", "0%");

      linearGradient.append("stop")
        .attr("offset", "0%")
        .style("stop-color", "#FED5E0");

      linearGradient.append("stop")
        .attr("offset", "100%")
        .style("stop-color", "#EA638C");

      legend.append('rect')
        .attr('width', 200)
        .attr('height', 10)
        .style('fill', 'url(#color-gradient)')
        .style('stroke', '#000'); 

    
      const ticks = [90, 110, 130, 150, 170, 180];
      const tickWidth = 40;

      legend.selectAll('.tick-label')
        .data(ticks)
        .enter().append('text')
        .attr('class', 'tick-label')
        .attr('x', (d, i) => i * tickWidth)
        .attr('y', 20)
        .attr('text-anchor', 'middle')
        .style('font-size', '8px')
        .text(d => d);
      });
    }, [selectedYear]);
  const handleSliderChange = (event) => {
    const newYear = parseInt(event.target.value, 10);
    setSelectedYear(newYear);
  };

  return (
    <div>
      <input
        type="range"
        min={1999}
        max={2020}
        step={1}
        value={selectedYear}
        onChange={handleSliderChange}
      />
      <div className="year-label">Year: {selectedYear}</div>
      <svg className="rounded-viz-container-med" ref={svgRef}></svg>
    </div>
  );
};

export default TrendMap;
