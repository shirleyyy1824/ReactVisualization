import React from 'react'
import HomeIcon from '@mui/icons-material/Home';
import WomanIcon from '@mui/icons-material/Woman';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
export const SidebarData =[
{
    title:"Home",
    icon:<HomeIcon />,
    link:"/home"
},
{
    title:"Demographic",
    icon:<WomanIcon />,
    link:"/demographic"
},
{
    title:"Cancer Rate",
    icon:<TrendingUpIcon />,
    link:"/rate"
},
{
    title:"Interventions",
    icon:<AccountBalanceIcon />,
    link:"/interventions"
},

]
  


