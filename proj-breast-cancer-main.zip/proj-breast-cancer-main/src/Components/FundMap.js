import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { feature } from 'topojson';

const FundMap = () => {
  const svgRef = useRef(null);

  useEffect(() => {
    const width = 580;
    const height = 400;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);

    const tooltip = d3.select("body").append("div")
      .attr("class", "tooltip")
      .style("opacity", 0);

    let fundData; 

    d3.json('/data/counties-10m.json').then(function (us) {
      const featureCollection = feature(us, us.objects.counties);
      const path = d3.geoPath()
        .projection(d3.geoAlbersUsa()
          .fitSize([470, 470], featureCollection));

      d3.json('/data/FundMap.json').then(function (stateData) {
        stateData.forEach(function (data) {
          data.state = standardizeStateName(data.state);
        });

        const customColorScale = d3.scaleSequential(d3.interpolateRgb('#FED5E0', '#EA638C'))
          .domain([0, d3.max(stateData, function (d) { return d.amount; })]);

        svg.append('g')
          .attr('class', 'states')
          .selectAll('path')
          .data(feature(us, us.objects.states).features)
          .enter()
          .append('path')
          .attr('d', path)
          .attr('fill', function (d) {
            const stateName = d.properties.name;
            fundData = stateData.find(function (data) {
              return data.state === stateName;
            });

            if (fundData) {
              return customColorScale(fundData.amount);
            } else {
              return 'gray';
            }
          })
          .on("mouseover", function (event, d) {
           
            fundData = stateData.find(function (data) {
              return data.state === d.properties.name;
            });
        
            tooltip.transition()
              .duration(200)
              .style("opacity", 0.9);
            tooltip.html(`${d.properties.name}<br/>Amount:$${fundData ? fundData.amount : 'N/A'}`)
              .style("left", (event.pageX) + "px")
              .style("top", (event.pageY - 28) + "px");
          })
          .on("mouseout", function () {
            tooltip.transition()
              .duration(500)
              .style("opacity", 0);
          });
          

        svg.append('text')
          .attr('x', width / 2)
          .attr('y', 20)
          .attr('text-anchor', 'middle')
          .style('font-size', '20px')
          .text('Breast Cancer Fund Choropleth Map');
        const legend = svg.append('g')
          .attr('class', 'legend')
          .attr('transform', 'translate(200, 50)');

        const legendScale = d3.scaleLinear()
          .domain([0, d3.max(stateData, function (d) { return d.amount; })])
          .range([0, 200]);

        const legendAxis = d3.axisBottom(legendScale)
          .ticks(5)
          .tickSize(10)
          .tickFormat(d3.format(".1s"));

        legend.append('g')
          .call(legendAxis);

        const defs = legend.append("defs");
        const linearGradient = defs.append("linearGradient")
          .attr("id", "color-gradient")
          .attr("x1", "0%")
          .attr("y1", "0%")
          .attr("x2", "100%")
          .attr("y2", "0%");

        linearGradient.append("stop")
          .attr("offset", "0%")
          .style("stop-color", '#FED5E0');

        linearGradient.append("stop")
          .attr("offset", "100%")
          .style("stop-color", '#EA638C');

        legend.append('rect')
          .attr('width', 200)
          .attr('height', 10)
          .style('fill', 'url(#color-gradient)');
      });
    });
  }, []);

  function standardizeStateName(name) {
    return name.split(' ').map(function (word) {
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join(' ');
  }

  return (
    <svg className="rounded-viz-container" ref={svgRef}></svg>
  );
};

export default FundMap;
