import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import regression from 'regression';

const Scatterplot = () => {
  const svgRef = useRef();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/data/scatter.json');
        const data = await response.json();

   
        d3.select(svgRef.current).selectAll('*').remove();

      
        const margin = { top: 40, right: 60, bottom: 60, left: 90 };
        const width = 500 - margin.left - margin.right;
        const height = 200 - margin.top - margin.bottom;

        
        const svg = d3.select(svgRef.current)
          .append('svg')
          .attr('width', width + margin.left + margin.right)
          .attr('height', height + margin.top + margin.bottom)
          .append('g')
          .attr('transform', `translate(${margin.left}, ${margin.top})`);

  
        const xScale = d3.scaleLinear()
          .domain([0, d3.max(data, d => d.screeningRate)])
          .range([0, width]);

        const yScale = d3.scaleLinear()
          .domain([0, d3.max(data, d => d.deathRate)])
          .range([height, 0]);

   
        svg.selectAll('.scatter-point')
          .data(data)
          .enter()
          .append('circle')
          .attr('class', 'scatter-point')
          .attr('cx', d => xScale(d.screeningRate))
          .attr('cy', d => yScale(d.deathRate))
          .attr('r', 4)
          .attr('fill', '#EA638C');

  
        svg.append('g')
          .attr('transform', `translate(0, ${height})`)
          .call(d3.axisBottom(xScale));

  
        svg.append('g')
          .call(d3.axisLeft(yScale));

      
        svg.append('text')
          .attr('text-anchor', 'middle')
          .attr('transform', `translate(${width / 2}, ${height + margin.bottom - 10})`)
          .text('Total 40 years and over female mammography screening rate, %');

        svg.append('text')
          .attr('text-anchor', 'middle')
          .attr('transform', 'rotate(-90)')
          .attr('y', 0 - margin.left)
          .attr('x', 0 - height / 2)
          .attr('dy', '1em')
          .text('Death rate, %');

     
        const regressionData = regression.linear(data.map(d => [d.screeningRate, d.deathRate]));

       
        svg.append('line')
          .attr('class', 'regression-line')
          .attr('x1', xScale(d3.min(data, d => d.screeningRate)))
          .attr('y1', yScale(regressionData.predict(d3.min(data, d => d.screeningRate))))
          .attr('x2', xScale(d3.max(data, d => d.screeningRate)))
          .attr('y2', yScale(regressionData.predict(d3.max(data, d => d.screeningRate))))
          .attr('stroke', '#5D2A42')
          .attr('stroke-width', 2);

       
        svg.append('text')
          .attr('x', width - 10)
          .attr('y', 10)
          .attr('text-anchor', 'end')
          .style('font-size', '14px')
          .text(`R^2 = ${d3.format('.4f')(regressionData.r2)}`);
      } catch (error) {
        console.error('Error fetching or processing data:', error);
      }
    };

    fetchData();
  }, []); 

  return <div className="rounded-viz-container-med" ref={svgRef}></div>;
};

export default Scatterplot;
