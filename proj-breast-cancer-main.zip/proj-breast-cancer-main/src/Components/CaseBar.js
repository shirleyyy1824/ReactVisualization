import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const CaseBar = () => {
  const chartRef = useRef();

  useEffect(() => {

    const cancerTypes = ["Breast", "Prostate", "Lung and Bronchus", "Colon and Rectum", "Melanoma of the Skin"];

    const newCasesData = [
      { type: "Breast", newCases: 300590 },
      { type: "Prostate", newCases: 288300 },
      { type: "Lung and Bronchus", newCases: 238340 },
      { type: "Colon and Rectum", newCases: 153020 },
      { type: "Melanoma of the Skin", newCases: 97610 }
    ];

    const deathCasesData = [
      { type: "Breast", deathCases: 43700 },
      { type: "Prostate", deathCases: 34700 },
      { type: "Lung and Bronchus", deathCases: 127070 },
      { type: "Colon and Rectum", deathCases: 52550 },
      { type: "Melanoma of the Skin", deathCases: 7990 }
    ];

   
    const margin = { top: 20, right: 140, bottom: 20, left: 160 };
    const width = 500 - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

   
    d3.select(chartRef.current).selectAll('*').remove();

 
    const svg = d3.select(chartRef.current)
      .append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

   
    const xScale = d3.scaleLinear()
      .domain([0, d3.max(newCasesData, d => d.newCases, d => d.deathCases)])
      .range([0, width]);

    const yScale = d3.scaleBand()
      .domain(cancerTypes)
      .range([0, height])
      .padding(0.3);

    svg.selectAll('.new-cases-bar')
      .data(newCasesData)
      .enter()
      .append('rect')
      .attr('class', 'new-cases-bar')
      .attr('x', 0)
      .attr('y', d => yScale(d.type) - yScale.bandwidth() / 4)
      .attr('width', d => xScale(d.newCases))
      .attr('height', yScale.bandwidth() / 2)
      .attr('fill', '#EA638C')
      .on('mouseover', function (event, d) {
       
        tooltip.transition()
          .duration(200)
          .style('opacity', 0.9);
        tooltip.html(`New Cases: ${d.newCases}`)
          .style('left', (event.pageX) + 'px')
          .style('top', (event.pageY - 28) + 'px');
      })
      .on('mouseout', function () {
 
        tooltip.transition()
          .duration(500)
          .style('opacity', 0);
      });

    svg.selectAll('.death-cases-bar')
      .data(deathCasesData)
      .enter()
      .append('rect')
      .attr('class', 'death-cases-bar')
      .attr('x', 0)
      .attr('y', d => yScale(d.type) + yScale.bandwidth() / 4)
      .attr('width', d => xScale(d.deathCases))
      .attr('height', yScale.bandwidth() / 2)
      .attr('fill', '#89023E')
      .on('mouseover', function (event, d) {
        
        tooltip.transition()
          .duration(200)
          .style('opacity', 0.9);
        tooltip.html(`Death Cases: ${d.deathCases}`)
          .style('left', (event.pageX) + 'px')
          .style('top', (event.pageY - 28) + 'px');
      })
      .on('mouseout', function () {
      
        tooltip.transition()
          .duration(500)
          .style('opacity', 0);
      });


    const tooltip = d3.select('body').append('div')
      .attr('class', 'tooltip')
      .style('opacity', 0);

   
    svg.append('g')
      .call(d3.axisLeft(yScale))
      .selectAll('text')
      .style('font-size', '14px'); 

    
    const legend = svg.append('g')
      .attr('transform', `translate(${width + 10}, 0)`);

    legend.append('rect')
      .attr('x', 10)
      .attr('y', 10)
      .attr('width', 20)
      .attr('height', 20)
      .attr('fill', '#EA638C');

    legend.append('text')
      .attr('x', 40)
      .attr('y', 20)
      .attr('dy', '0.8em')
      .style('text-anchor', 'start')
      .style('font-size', '14px')
      .text('New Cases');

    legend.append('rect')
      .attr('x', 10)
      .attr('y', 40)
      .attr('width', 20)
      .attr('height', 20)
      .attr('fill', '#89023E');

    legend.append('text')
      .attr('x', 40)
      .attr('y', 50)
      .attr('dy', '0.8em')
      .style('text-anchor', 'start')
      .style('font-size', '14px')
      .text('Death Cases');
  }, []);

  return <div className="rounded-viz-container-med" ref={chartRef} ></div>;
};

export default CaseBar;

