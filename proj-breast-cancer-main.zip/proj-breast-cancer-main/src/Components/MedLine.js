import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const MedLine = () => {
  const chartRef = useRef();

  useEffect(() => {
    const fetchData = async () => {
      try {
  
        const response = await fetch('/data/line1.json');
        const data = await response.json();

        
        d3.select(chartRef.current).selectAll('*').remove();

     
        const margin = { top: 40, right: 30, bottom: 60, left: 60 };
        const width = 500 - margin.left - margin.right;
        const height = 300 - margin.top - margin.bottom;

   
        const svg = d3.select(chartRef.current)
          .append('svg')
          .attr('width', width + margin.left + margin.right)
          .attr('height', height + margin.top + margin.bottom)
          .append('g')
          .attr('transform', `translate(${margin.left}, ${margin.top})`);

     
        const parseTime = d3.timeParse('%Y');
        data.forEach(d => {
          d.year = parseTime(`${d.year}`);
        });

    
        const xScale = d3.scaleTime()
          .domain(d3.extent(data, d => d.year))
          .range([0, width]);

        const yScale = d3.scaleLinear()
          .domain([0, d3.max(data, d => Math.max(d.incidenceTrend, d.deathTrend))])
          .range([height, 0]);

        
        const incidenceLine = d3.line()
          .x(d => xScale(d.year))
          .y(d => yScale(d.incidenceTrend));

        const deathLine = d3.line()
          .x(d => xScale(d.year))
          .y(d => yScale(d.deathTrend));

       
        svg.append('path')
          .data([data])
          .attr('class', 'line')
          .attr('d', incidenceLine)
          .style('stroke', '#5D2A42')
          .style('fill', 'none')
          .style('stroke-width', 3);


        svg.append('path')
          .data([data])
          .attr('class', 'line')
          .attr('d', deathLine)
          .style('stroke', '#EA638C')
          .style('fill', 'none')
          .style('stroke-width', 3);

      
        svg.append('g')
          .attr('transform', `translate(0, ${height})`)
          .call(d3.axisBottom(xScale)
            .ticks(d3.timeYear.every(5))
            .tickFormat(d3.timeFormat('%Y')));


        svg.append('g')
          .call(d3.axisLeft(yScale));
        svg.append('text')
          .attr('transform', 'rotate(-90)')
          .attr('y', 0 - margin.left)
          .attr('x', 0 - height / 2)
          .attr('dy', '1em')
          .style('text-anchor', 'middle')
          .style('font-size', '14px')
          .text('Rate Cases Per 100,000');

        const legend = svg.append('g')
          .attr('class', 'legend')
          .attr('transform', `translate(${width - 200}, ${height + margin.bottom / 2})`);

        legend.append('rect')
          .attr('width', 20)
          .attr('height', 2)
          .attr('fill', '#5D2A42');

        legend.append('text')
          .attr('x', 30)
          .attr('y', 5)
          .style('font-size', '14px')
          .text('Incidence Trend');

        legend.append('rect')
          .attr('y', 20)
          .attr('width', 20)
          .attr('height', 2)
          .attr('fill', '#FB6376');

        legend.append('text')
          .attr('x', 30)
          .attr('y', 25)
          .style('font-size', '14px')
          .text('Death Trend');
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return <div className="rounded-viz-container-med" ref={chartRef}></div>;
};

export default MedLine;
