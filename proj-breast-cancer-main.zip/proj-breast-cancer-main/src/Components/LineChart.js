import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

export default function LineChart() {
  const chartRef = useRef();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/data/line.json');
        const data = await response.json();

        d3.select(chartRef.current).selectAll('*').remove();

        const margin = { top: 20, right: 20, bottom: 32, left: 50 };
        const width = 500 - margin.left - margin.right;
        const height = 150 - margin.top - margin.bottom;
        const svg = d3.select(chartRef.current)
          .append('svg')
          .attr('width', width + margin.left + margin.right)
          .attr('height', height + margin.top + margin.bottom)
          .append('g')
          .attr('transform', `translate(${margin.left},${margin.top})`);

        const xScale = d3.scaleLinear()
          .domain(d3.extent(data, d => d.year))
          .range([0, width]);

        const yScale = d3.scaleLinear()
          .domain([0, d3.max(data, d => d.fund)])
          .range([height, 0]);

        const line = d3.line()
          .x(d => xScale(d.year))
          .y(d => yScale(d.fund));

        svg.append('path')
          .datum(data)
          .attr('fill', 'none')
          .attr('stroke', '#EA638C')
          .attr('stroke-width', 3)
          .attr('d', line);

        svg.selectAll('circle')
          .data(data)
          .enter().append('circle')
          .attr('cx', d => xScale(d.year))
          .attr('cy', d => yScale(d.fund))
          .attr('r', 5)
          .attr('fill', '#EA638C')
          .on('mouseover', handleMouseOver)
          .on('mouseout', handleMouseOut);

        svg.append('g')
          .attr('transform', `translate(0, ${height})`)
          .call(d3.axisBottom(xScale));
        svg.append('g')
          .call(d3.axisLeft(yScale));
        svg.append('text')
          .attr('x', width / 2)
          .attr('y', height + margin.top + 12)
          .style('text-anchor', 'middle')
          .text('Year');
        svg.append('text')
          .attr('transform', 'rotate(-90)')
          .attr('x', -height / 2)
          .attr('y', -margin.left + 13)
          .style('text-anchor', 'middle')
          .text('Fund');

        function handleMouseOver(event, d) {
          d3.select(event.target)
            .attr('fill', '#89023E');
          const tooltip = d3.select('body').append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0)
            .style('position', 'absolute')
            .style('background-color', 'white')
            .style('border', '1px solid #EA638C')
            .style('border-radius', '5px')
            .style('padding', '10px');

          tooltip.transition()
            .duration(200)
            .style('opacity', 0.9);

          tooltip.html(`Year: ${d.year}<br/>Fund:$${d.fund}`)
            .style('left', `${event.pageX}px`)
            .style('top', `${event.pageY - 50}px`);
        }

        function handleMouseOut(event, d) {
          d3.select(event.target)
            .attr('fill', '#EA638C');
        
          const tooltip = d3.select('.tooltip');
          
          tooltip.transition()
            .duration(500)
            .style('opacity', 0)
            .on('end', function () {
             
              d3.select(this).remove();
            });
        }
        
        

      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (

    <div className="rounded-viz-container" ref={chartRef}>
    </div>
    
  );
}
