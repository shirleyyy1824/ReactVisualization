import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const AgeBar = () => {
  const svgRef = useRef();

  useEffect(() => {
    
    fetch('/data/age.json')
      .then((response) => response.json())
      .then((data) => {
      
        const svg = d3.select(svgRef.current);

        const margin = { top: 60, right: 40, bottom: 30, left: 60 }; 
        const width = 600 - margin.left - margin.right;
        const height = 300 - margin.top - margin.bottom;

        const xScale = d3
          .scaleBand()
          .domain(data.map((d) => d.age))
          .range([60, width])
          .padding(0.1);

        const yScale = d3
          .scaleLinear()
          .domain([40, d3.max(data, (d) => d.rate)])
          .range([height, 0]);

        svg
          .selectAll('.bar')
          .data(data)
          .enter()
          .append('rect')
          .attr('class', 'bar')
          .attr('x', (d) => xScale(d.age))
          .attr('y', (d) => yScale(d.rate))
          .attr('width', xScale.bandwidth())
          .attr('height', (d) => height - yScale(d.rate))
          .attr('fill', '#EA638C')
          .on('mouseover', (event, d) => {
            tooltip.transition().duration(200).style('opacity', 0.9);
            tooltip
              .html(`Age: ${d.age}<br>Rate: ${d.rate}`)
              .style('left', event.pageX + 'px')
              .style('top', event.pageY - 28 + 'px');
          })
          .on('mouseout', () => {
            tooltip.transition().duration(500).style('opacity', 0);
          });
        svg
          .append('g')
          .attr('transform', `translate(0, ${height})`)
          .call(d3.axisBottom(xScale));

       
        const yAxis = svg
          .append('g')
          .attr('transform', `translate(${margin.left}, 0)`) 
          .call(d3.axisLeft(yScale));

        svg
          .append('text')
          .attr('transform', 'rotate(-90)')
          .attr('y', 8)
          .attr('x', 0 - height / 2)
          .attr('dy', '1em')
          .style('text-anchor', 'middle')
          .text('Rate per 100,000 people');
        
        svg
          .append('text')
          .attr('x', width / 2 + margin.left)
          .attr('y', 260)
          .attr('text-anchor', 'middle')
          .style('font-size', '16px')
          .text('Rate of New Cancers By Age Group');
      
        yAxis.selectAll('.tick text').attr('font-size', '10');

      
        const tooltip = d3
          .select('body')
          .append('div')
          .attr('class', 'tooltip')
          .style('opacity', 0);
      });
  }, []);

  return (
    <div>
      <svg className="rounded-viz-container-med" ref={svgRef} width={580} height={300}></svg>
    </div>
  );
};

export default AgeBar;
