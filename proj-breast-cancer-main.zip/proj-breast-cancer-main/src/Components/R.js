import React, { useState, useEffect } from 'react';
import '../App.css';

const R = () => {
  const [currentImage, setCurrentImage] = useState(1);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prevImage) => (prevImage % 3) + 1);
    }, 2000);

    return () => clearInterval(interval); 
  }, []);

  return (
    <div className="r-container" >
      <img
        className={`r-image ${currentImage === 1 ? 'active' : ''}`}
        src="/data/3d(1).png" 
        alt="Image 1"
        style={{ width: '600px' }}
      />
      <img
        className={`r-image ${currentImage === 2 ? 'active' : ''}`}
        src="/data/3d(2).png" 
        alt="Image 2"
        style={{ width: '600px' }}
      />
      <img
        className={`r-image ${currentImage === 3 ? 'active' : ''}`}
        src="/data/3d(3).png" 
        alt="Image 3"
        style={{ width: '600px' }}
      />
    </div>
  );
};

export default R;
