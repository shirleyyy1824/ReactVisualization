import React, { useState, useEffect } from 'react';
import "../App.css";
import { SidebarData } from './SidebarData';
import logo from './logo.png';

function SideBar() {
  const [activeLink, setActiveLink] = useState("");

  useEffect(() => {
   
    setActiveLink(window.location.pathname);
  }, []);

  return (
    <div className="Sidebar">
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img
          src={logo}
          alt="logo"
          style={{ height: '52px', width: '60px' }}
        />
        <h1>Breast Cancer Dashboard</h1>
      </div>
      <ul className="SidebarList">
        {SidebarData.map((val, key) => {
          const isActive = val.link === activeLink;
          return (
            <li
              key={key}
              className={`row ${isActive ? 'active' : ''}`}
              onClick={() => {
                window.location.pathname = val.link;
                setActiveLink(val.link);
              }}
            >
              <div id="icon">{val.icon}</div>
              <div id="title">{val.title}</div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export default SideBar;

