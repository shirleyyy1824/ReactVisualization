import React, { useState } from 'react';
import FundMap from './FundMap';
import TrendMap from './TrendMap';
import Mammography from './Mammography';
import R from './R'; // Import the R component
import '../App.css';

const MapToggle = () => {
  const [showFundMap, setShowFundMap] = useState(true);
  const [showTrendMap, setShowTrendMap] = useState(false);
  const [showMammography, setShowMammography] = useState(false);
  const [showR, setShowR] = useState(false); // State to control the visibility of the R component

  const showFundMapHandler = () => {
    setShowFundMap(true);
    setShowTrendMap(false);
    setShowMammography(false);
    setShowR(false); // Hide the R component when showing other maps
  };

  const showTrendMapHandler = () => {
    setShowFundMap(false);
    setShowTrendMap(true);
    setShowMammography(false);
    setShowR(false); // Hide the R component when showing other maps
  };

  const showMammographyHandler = () => {
    setShowFundMap(false);
    setShowTrendMap(false);
    setShowMammography(true);
    setShowR(false); // Hide the R component when showing other maps
  };

  const showRHandler = () => {
    setShowR(true);
    setShowFundMap(false);
    setShowTrendMap(false);
    setShowMammography(false);
  };

  return (
    <div>
      <button onClick={showFundMapHandler} className="button">
        Fund Map
      </button>
      <button onClick={showTrendMapHandler} className="button">
        Trend Map
      </button>
      <button onClick={showMammographyHandler} className="button">
        Mammography Map
      </button>
      <button onClick={showRHandler} className="button">
        3D Uninsured Map
      </button>

      {showFundMap ? <FundMap /> : null}
      {showTrendMap ? <TrendMap /> : null}
      {showMammography ? <Mammography /> : null}
      {showR ? <R /> : null} 
    </div>
  );
};

export default MapToggle;
