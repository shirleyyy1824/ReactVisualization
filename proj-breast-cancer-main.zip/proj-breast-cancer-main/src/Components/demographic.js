
import React from 'react';
import SideBar from './SideBar';
import "../App.css";
import AgeBar from './AgeBar';
import RaceBar from './RaceBar';
import PieChart from './PieChart';


const Demographic = () => {
  return (
    <div className="container-fluid">
   <div className="row ">
     
      <div className="col-sm-2">
        <SideBar />
      </div>
      <div className="col-sm-10">
        <p className="textbox">Breast cancer can affect women of all ages, including those in their 20s and 30s
        The cancer risk increases with age.<br/> The majority of breast cancer cases occur in women over the age of 50.<br/>
        Breast cancer incidence rates can vary among different racial and ethnic groups.
In the United States, for example, non-Hispanic white women generally have higher breast cancer incidence rates compared to 
African American, Hispanic, Asian/Pacific Islander, and American Indian/Alaska Native women.<br/>
This interactive donut chart offers a detailed breakdown of mammography screening rates by age group, realizing the age group selection with a click button. It provides valuable insights into which age groups are more or less likely to undergo screening, potentially informing targeted interventions or public health campaigns.</p>
      </div>
      <div className="col-lg-5">
        <AgeBar/>
        <PieChart/>
      </div>
      <div className="col-lg-5"><RaceBar/></div>
      </div>
      </div>
  );
};

export default Demographic;
