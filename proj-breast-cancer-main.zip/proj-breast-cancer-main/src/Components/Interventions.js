import React from 'react';
import SideBar from './SideBar';
import "../App.css";
import LineChart from './LineChart'; 
import Mammography from './Mammography';
import R from './R';
import FundMap from './FundMap';

const Interventions = () => {
    return (
      <div className="container-fluid">
     <div className="row ">
        {/* Navigation Bar (on the far left) */}
        <div className="col-sm-2">
          <SideBar />
        </div>
    
        <div className="col-lg-5">
          <LineChart/> <br/>
          <R/>
          <Mammography/>
          <FundMap/>
        </div>
        <div className="col-lg-5">
        <p className="textbox">The funding dedicated to breast cancer has experienced growth over time and is anticipated to continue its upward trajectory into the year 2024.</p>
        <br/><br/><br/><br/><br/><br/>
        <p className="textbox">This image depicts a 3D rendered map of the United States, color-coded to display the percentage of uninsured individuals by county. The third dimension adds a visual impact to the data, making the variations between counties more pronounced and easier to discern at a glance. One advantage of a 3D rendered map is that it allows for a more nuanced understanding of geographical data, as the height can be used to represent additional variables, such as population density or, in this case, the uninsured rate. Another advantage is the aesthetic appeal, which can engage viewers more effectively than a flat map. Finally, a 3D map can reveal patterns that might not be as obvious in 2D, providing a unique perspective on spatial relationships and data distribution.</p>
        <br/><br/><br/><br/><br/><br/><br/><br/>
        <p className="textbox">Mammography facilities play a crucial role in breast cancer screening and early detection. 
        They contribute to public health initiatives, support clinical decision-making, 
        and ultimately save lives by identifying breast cancer at its earliest and most treatable stages. 
        Regular screening and access to mammography services are essential elements in the fight against breast cancer. 
        The map indicates that regions on the East Coast, characterized by higher population densities and greater urbanization, generally exhibit a higher prevalence of mammography facilities.</p>
        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
        <p className="textbox">New York, Texas, and California are among the most populous states in the United States. 
        The large population size and density may result in a higher burden of breast cancer cases, 
        prompting increased funding for research, prevention, and treatment.</p>
        </div>
        </div>
        </div>
    );
  };
  
  export default Interventions;
  