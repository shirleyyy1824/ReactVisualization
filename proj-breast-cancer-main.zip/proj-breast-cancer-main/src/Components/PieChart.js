import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import '../App.css';
const PieChart = () => {
  const chartContainerRef = useRef(null);
  const [selectedAgeGroup, setSelectedAgeGroup] = useState('40–49 years');

  const initialData = [
    { ageGroup: '40–49 years', screeningRate: 60.2 },
    { ageGroup: '50–64 years', screeningRate: 75.7 },
    { ageGroup: '65–74 years', screeningRate: 78.1 },
    { ageGroup: '75 years and over', screeningRate: 54.2 }
  ];

  const drawDonutChart = (svg, data) => {
    svg.selectAll('*').remove();

    const screeningRate = data.length > 0 ? data[0].screeningRate : 0;
    const nonScreeningRate = 100 - screeningRate;

    const color = d3.scaleOrdinal()
      .domain(['screeningRate', 'nonScreeningRate'])
      .range(['#89023E', '#EA638C']);

    const pie = d3.pie()
      .value(d => d.value)
      .sort(null);

    const pieData = pie([
      { value: screeningRate, type: 'screeningRate' },
      { value: nonScreeningRate, type: 'nonScreeningRate' }
    ]);

    const arc = d3.arc()
      .innerRadius(50)
      .outerRadius(100);

    const labelArc = d3.arc()
      .innerRadius(120)
      .outerRadius(120);

    svg.selectAll('path')
      .data(pieData)
      .enter()
      .append('path')
      .attr('d', arc)
      .attr('fill', d => color(d.data.type));

   
    const screeningData = pieData.filter(d => d.data.type === 'screeningRate');

    svg.selectAll('polyline')
      .data(screeningData)
      .enter()
      .append('polyline')
      .attr('stroke', 'black')
      .attr('stroke-width', 1)
      .attr('fill', 'none')
      .attr('points', d => {
        const posA = arc.centroid(d);
        const posB = labelArc.centroid(d);
        const posC = labelArc.centroid(d);
        posC[0] = 200; 
        return [posA, posB, posC];
      });

    svg.selectAll('text')
      .data(screeningData)
      .enter()
      .append('text')
      .attr('transform', d => {
        const pos = labelArc.centroid(d);
        pos[0] = 230; 
        return `translate(${pos})`;
      })
      .attr('text-anchor', 'start')
      .text(d => `${d.data.value}%`);

    const legend = svg.append('g')
      .attr('transform', 'translate(-100,260)');

    legend.selectAll('rect')
      .data(pieData)
      .enter()
      .append('rect')
      .attr('x', 0)
      .attr('y', (d, i) => 20 * i-160)
      .attr('width', 20)
      .attr('height', 20)
      .attr('fill', d => color(d.data.type));

    legend.selectAll('text')
      .data(pieData)
      .enter()
      .append('text')
      .attr('x', 30)
      .attr('y', (d, i) => 20 * i-140)
      .text(d => d.data.type === 'screeningRate' ? 'Screening Rate' : 'Non-Screening Rate');
  };

  useEffect(() => {
    const chartContainer = d3.select(chartContainerRef.current);
    const svg = chartContainer.select('svg').select('g');

    if (svg.empty()) {
      const newSvg = chartContainer
        .append('svg')
        .attr('width', 400)
        .attr('height', 250)
        .append('g')
        .attr('transform', 'translate(100,100)');

      drawDonutChart(newSvg, initialData);

      return () => {
        newSvg.selectAll('*').remove();
      };
    } else {
    
      const filteredData = initialData.filter(d => d.ageGroup === selectedAgeGroup);
      drawDonutChart(svg, filteredData);
    }
  }, [selectedAgeGroup]);

  return (
    <div>
    
      <select
        id="ageGroupSelect"
        onChange={(e) => setSelectedAgeGroup(e.target.value)}
        value={selectedAgeGroup}
      >
        {initialData.map((d) => (
          <option key={d.ageGroup} value={d.ageGroup}>
            {d.ageGroup}
          </option>
        ))}
      </select>

      <div className="rounded-viz-container-med" ref={chartContainerRef} />
    </div>
  );
};

export default PieChart;
