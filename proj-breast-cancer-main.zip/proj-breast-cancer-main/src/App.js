// import React from 'react';
// import "./App.css";
// import DataViz from './Components/DataViz';
// function App() {
//   return (
 
//   <DataViz/> );
// }

// export default App;
// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import DataViz from './Components/DataViz';
import Demographic from './Components/demographic'; 
import Rate from './Components/Rate'; 
import Interventions from './Components/Interventions'; 

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<DataViz/>} />
        <Route path="/home" element={<DataViz/>} />
        <Route path="/demographic" element={<Demographic />} />
        <Route path="/rate" element={<Rate />} />
        <Route path="/interventions" element={<Interventions />} />
      </Routes>
    </Router>
  );
}

export default App;
